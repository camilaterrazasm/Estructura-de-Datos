#include "StdAfx.h"
#include "Paralelogramo.h"
#include "iostream"
#include "conio.h"
using namespace std;

int main(void) {
   Paralelogramo Para;
 
   Para.setWidth(5);
   Para.setHeight(7);

   cout << "Total area: " << Para.getArea2() << endl;
   getch();
   return 0;
}