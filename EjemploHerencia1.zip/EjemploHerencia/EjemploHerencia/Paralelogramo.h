#pragma once
#include "Shape.h"
class Paralelogramo: public Shape
{
public:
	Paralelogramo(void);
	~Paralelogramo(void);
	int getArea2() { 
         return (width * height); 
      }
};

